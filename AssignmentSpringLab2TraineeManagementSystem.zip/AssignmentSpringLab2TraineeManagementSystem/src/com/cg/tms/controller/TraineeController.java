package com.cg.tms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.tms.entities.Login;
import com.cg.tms.entities.Trainee;
import com.cg.tms.service.TraineeService;

@Controller
public class TraineeController 
{

	@Autowired
	TraineeService tser;
	
	@RequestMapping("start")
	public String LogIn(Model model)
	{
		Login ldetails=new Login();
		model.addAttribute("ldetails",ldetails);
		return "Login";
	}
	
	@RequestMapping("Logindetails")
	public String LoginInputs(@Valid@ModelAttribute("ldetails")Login ldetails,BindingResult res, Model model)
	{
		if(res.hasErrors())
		{
			return "Login";
		}
		
		else
			return "Choice";
		
	}
	
	@RequestMapping("Add")
	public String AddTrainee(Model model)
	{
		Trainee tdetails=new Trainee();
		model.addAttribute("tdetails", tdetails);
		
		return "TraineeInfo";
	}
	
	@RequestMapping("Addtodb")
	public String AddToDB(@Valid@ModelAttribute("tdetails")Trainee tdetails,BindingResult res,Model model)
	{
		
		if(res.hasErrors())
		{
			model.addAttribute("tdetails", tdetails);
			return"TraineeInfo";
		}
		
		else
		{
			model.addAttribute("tdetails", tdetails);
			tser.insertTrainee(tdetails);
			return "success";
			
		}
	}
	
	@RequestMapping("RetrieveAll")
	public String GetAllTrainee(Model model)
	{
		List<Trainee> tList=tser.showAllTrainee();
		model.addAttribute("tList", tList);
		
		return "Display";
		
	}
		
	@RequestMapping("Delete")
	public String DeleteTrainee(Model model)
	{
		return "TraineeDelete";
	}
	
	@RequestMapping("DeleteTrainee")
	public String DeleteFromDB(@RequestParam("tid")Integer tid,Model model)
	{
		model.addAttribute("tid", tid);
		tser.deleteTrainee(tid);
		return "success";
		
	}
	
	@RequestMapping("Modify")
	public String ModifyTrainee(Model model)
	{
		Trainee mdetails=new Trainee();
		model.addAttribute("mdetails", mdetails);
		return "TraineeModify";
	}
	
	@RequestMapping("ModifyInfo")
	public String ModifyInDB(@ModelAttribute("mdetails")Trainee mdetails,BindingResult res,Model model)
	{
		model.addAttribute("mdetails", mdetails);
		tser.modifyTrainee(mdetails);
		return "success";
		
	}
	
	
}
