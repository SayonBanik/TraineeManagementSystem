package com.cg.tms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.NotFound;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="Trainee_157998")
public class Trainee 
{

	@Id
	@SequenceGenerator(name="seq",sequenceName="Trainee_Seq",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@Column(name="TRAINEE_ID")
	private Integer traineeId;
	
	@Column(name="TRAINEE_NAME")
	@NotNull(message="Trainee Name cannot be empty.Please Enter Trainee name")
	private String traineeName;
	
	@NotNull(message="Please select Trainee Domain")
	@Column(name="TRAINEE_DOMAIN")
	private String traineeDomain;
	
	@NotNull(message="Please select trainee Location")
	@Column(name="TRAINEE_LOCATION")
	private String traineeLocation;
	
	

	public Trainee() 
	{
		
	}

	public Integer getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(Integer traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	
	
	
	
	
}
