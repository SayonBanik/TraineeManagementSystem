package com.cg.tms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.tms.dao.TraineeDao;
import com.cg.tms.entities.Trainee;

@Transactional
@Service
public class TraineServiceImpl implements TraineeService
{

	@Autowired
	TraineeDao tdao;
	
	@Override
	public List<Trainee> showAllTrainee() 
	{
		
		return tdao.showAllTrainee();
	}

	@Override
	public void insertTrainee(Trainee tdetails) 
	{
		tdao.insertTrainee(tdetails);

	}

	@Override
	public void deleteTrainee(Integer tid)
	{
		tdao.deleteTrainee(tid);
		
	}

	@Override
	public void modifyTrainee(Trainee tdetails) 
	{
		tdao.modifyTrainee(tdetails);
		
	}

}
