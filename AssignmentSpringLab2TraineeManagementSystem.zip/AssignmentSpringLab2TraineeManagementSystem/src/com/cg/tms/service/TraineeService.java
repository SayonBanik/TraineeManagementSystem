package com.cg.tms.service;

import java.util.List;

import com.cg.tms.entities.Trainee;

public interface TraineeService 
{

	public List<Trainee> showAllTrainee();
	
	public void insertTrainee(Trainee tdetails);
	
	public void deleteTrainee(Integer tid);
	
	public void modifyTrainee(Trainee tdetails);
}
