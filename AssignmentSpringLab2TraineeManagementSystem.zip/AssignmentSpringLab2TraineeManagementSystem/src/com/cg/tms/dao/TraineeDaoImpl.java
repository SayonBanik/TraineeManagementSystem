package com.cg.tms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.tms.entities.Trainee;

@Repository
public class TraineeDaoImpl implements TraineeDao 
{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<Trainee> showAllTrainee() 
	{
		String jpql="SELECT t from Trainee t";
		TypedQuery<Trainee> query=em.createQuery(jpql,Trainee.class);
		return query.getResultList();
	}

	@Override
	public void insertTrainee(Trainee tdetails) 
	{
		em.persist(tdetails);

	}

	@Override
	public void deleteTrainee(Integer tid)
	{
		Trainee trainee=em.find(Trainee.class, tid);
		em.remove(trainee);
		
	}

	@Override
	public void modifyTrainee(Trainee tdetails) 
	{
		
		em.merge(tdetails);
	}

}
