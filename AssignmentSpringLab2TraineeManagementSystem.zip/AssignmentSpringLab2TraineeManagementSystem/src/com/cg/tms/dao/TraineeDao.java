package com.cg.tms.dao;

import java.util.List;

import com.cg.tms.entities.Trainee;

public interface TraineeDao
{

	public List<Trainee> showAllTrainee();
	
	public void insertTrainee(Trainee tdetails);
	
	public void deleteTrainee(Integer tid);
	
	public void modifyTrainee(Trainee tdetails);
}
